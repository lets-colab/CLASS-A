# Erfan / Dr.X - selected implementation and verification source

This archive contains selected application code and the exact scoped tests used by the public professional profile. It is an inspectable implementation sample, not a complete offline website export.

Requires Node.js 22+ (the recorded check used Node.js 24). No npm install is required.

Run: npm test

The tests check source routing, unknown and private-data boundaries, validation of source selection, public proof claims, curriculum design semantics and actual second-brain connection boundaries. They do not run a browser, download the AI model, independently audit career claims or measure client/business outcomes.

Erfan supplied the brief, professional context and creative direction. AI tools assisted with the implementation and tests. The public curriculum outline summarizes a saved curriculum design; it does not certify course delivery or student results.

This source sample accompanies the Site’s proof-of-work page.
